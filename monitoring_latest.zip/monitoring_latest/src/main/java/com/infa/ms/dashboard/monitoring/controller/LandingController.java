package com.infa.ms.dashboard.monitoring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerStatus;
import com.infa.ms.dashboard.monitoring.model.CustomerMSDetail;
import com.infa.ms.dashboard.monitoring.model.MasterData;
import com.infa.ms.dashboard.monitoring.repository.MasterDataRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerMSDetailRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerStatusRepository;

@Controller
public class LandingController {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerStatusRepository custStatusRepository;
	
	@Autowired
	CustomerMSDetailRepository customerMSDetailRepository;
	
	@Autowired
	MasterDataRepository masterDataRepository;

	@GetMapping("/home")
	public String greeting(@RequestParam(name = "name", required = false, defaultValue = "World") String name,
			Model model) {
		System.out.println("*****************");
		model.addAttribute("name", name);
		model.addAttribute("customerList", customerRepository.findAll());
		List<CustomerStatus> aaa = custStatusRepository.findAll();
		System.out.println("\n\n******status**" + aaa.get(0).getCustomer().getId());
		model.addAttribute("statusList", custStatusRepository.findAll());
		model.addAttribute("consultant", customerMSDetailRepository.findAll());
		model.addAttribute("component",masterDataRepository.findByGroupID(3));
		return "CustomersSummary";

	}
	
	@GetMapping("/getcustomers")
	public String customers(@RequestParam(name = "prodname", required = true, defaultValue = "None") String prodname,
			Model model) {
		System.out.println("*****************");
		System.out.println(prodname);
		model.addAttribute("prodname", prodname);
		
		return "productDetail";

	}


	
	@GetMapping("/employee")
	public String employee(@RequestParam(name = "name", required = false, defaultValue = "World") String name,
			Model model) {
		System.out.println("*****************");
		model.addAttribute("name", "Test");
		return "employee";
	}

	@GetMapping("/test")
	public String test(@RequestParam(name = "name", required = false, defaultValue = "World") String name,
			Model model) {
		System.out.println("*****************");
		model.addAttribute("name", name);
		model.addAttribute("customerList", customerRepository.findAll());
		List<CustomerStatus> aaa = custStatusRepository.findAll();
		System.out.println("\n\n******status**" + aaa.get(0).getCustomer().getId());
		model.addAttribute("statusList", custStatusRepository.findAll());
		return "dashboard";
	}
}
