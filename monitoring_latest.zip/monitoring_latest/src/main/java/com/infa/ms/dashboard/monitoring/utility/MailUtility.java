package com.infa.ms.dashboard.monitoring.utility;

import java.net.PasswordAuthentication;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.springframework.stereotype.Component;

import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;
import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerJobInformation;

@Component
public class MailUtility {
	String Smtp_Host = "PS23EXVCL01.informatica.com";
	String Smtp_Port = "25";
	String Smtp_Trust = "PS23EXVCL01.informatica.com";
	String Smtp_Auth = "false";

	public void sendCusotmerStatus(Customer customer) {

		// Recipient's email ID needs to be mentioned.
		String to = customer.getCustomerMSDetail().get(0).getPersonContact();
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss");

		// Sender's email ID needs to be mentioned
		String from = "managedservices@informatica.com";

		// final String username = properties.getSmtp_Username();
		// final String password = properties.getSmtp_Password();

		Properties props = new Properties();
		props.put("mail.smtp.auth", Smtp_Auth);
		props.put("mail.smtp.starttls.enable", Smtp_Trust);
		props.put("mail.smtp.host", Smtp_Host);
		props.put("mail.smtp.port", Smtp_Port);

		// Get the Session object.
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new javax.mail.PasswordAuthentication(null, null);
			}
		});

		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.

			String[] tokens = to.split(",");
			for (int i = 0; i < tokens.length; i++) {
				Address address = new InternetAddress(tokens[i]);
				message.addRecipient(RecipientType.TO, address);
			}

			// Set Subject: header field
			message.setSubject(customer.getName() + " - Job Monitoring Statistics");

			StringBuilder jobHeader = new StringBuilder("<table style='border:1px solid black' cellspacing='15'>"
					+ "<tr><td>JobID</td><td>Job Type</td><td>Job Name</td><td>Job Status</td><td>Execution Time</td></tr >");

			
			StringBuilder exportContent = new StringBuilder();
			StringBuilder importContent = new StringBuilder();
			StringBuilder otherContent = new StringBuilder();
			List<CustomerJobInformation> joblist = customer.getCustomerJobInformation();
			for (CustomerJobInformation jobInfo : joblist) {
				String jobID = jobInfo.getJobID();
				String jobType = jobInfo.getJobType();
				String jobName = jobInfo.getJobName();
				String jobStatus = jobInfo.getJobStatus();
				String executionTime = jobInfo.getExecutionDate();
				if (jobInfo.getJobGroup().equals("Export")) {
					exportContent.append("<tr><td>" + jobID + "</td><td>" + jobType + "</td><td>" + jobName + "</td>");
					if (jobStatus.contains("errors")) {
						exportContent.append("<td style='color:red'>" + jobStatus + "</td>");
					} else {
						exportContent.append("<td>" + jobStatus + "</td>");
					}
					exportContent.append("<td>" + executionTime + "</td></tr>");
				} else if (jobInfo.getJobGroup().equals("ImportGroup")) {
					importContent.append("<tr><td>" + jobID + "</td><td>" + jobType + "</td><td>" + jobName + "</td>");
					if (jobStatus.contains("errors")) {
						importContent.append("<td style='color:red'>" + jobStatus + "</td>");
					} else {
						importContent.append("<td>" + jobStatus + "</td>");
					}
					importContent.append("<td>" + executionTime + "</td></tr>");
				} else {
					otherContent.append("<tr><td>" + jobID + "</td><td>" + jobType + "</td><td>" + jobName + "</td>");
					if (jobStatus.contains("errors")) {
						otherContent.append("<td style='color:red'>" + jobStatus + "</td>");
					} else {
						otherContent.append("<td>" + jobStatus + "</td>");
					}
					otherContent.append("<td>" + executionTime + "</td></tr>");
				}
			}
			exportContent.append("</table>");
			importContent.append("</table>");
			otherContent.append("</table>");

			
			String statusContent="<p style='background-color: #80ced6'> Customer"+customer.getName()+"&nbsp;&nbsp;&nbsp;&nbsp;"+customer.getCustomerStatus().getStatus()+"&nbsp;&nbsp;&nbsp;&nbsp;"+customer.getCustomerStatus().getLastUpdate()+"</p>";
			
			StringBuilder serviceContent = new StringBuilder("<table style='border:1px solid black' cellspacing='15'>"
					+ "<tr >" + "<td>ServiceName</td><td>Status</td>" + "<td>Last Updated</td></tr >");
			for(CustInfaProductDetail productInfo: customer.getCustInfaProductDetail()){
				
				serviceContent.append("<tr><td>"+productInfo.getComponent()+"</td>");
						
				if(productInfo.getCustomerServiceStatus().getStatus().equals("Unstable")){
					serviceContent.append("<td style='color:red'>"+productInfo.getCustomerServiceStatus().getStatus()+"</td>");
				}else{
					serviceContent.append("<td>"+productInfo.getCustomerServiceStatus().getStatus()+"</td>");
				}
				
				serviceContent.append("<td>"+productInfo.getCustomerServiceStatus().getMonitoringDate()+"</td></tr>");
			}
			serviceContent.append("</table>");
			
			String mailbody = statusContent+"</br>"+serviceContent.toString()+"</br>"
					+ "<p style='color: Blue'>Export Job</p>"+jobHeader.append(exportContent.toString()).toString()
			+"</br><p style='color: Blue'>Import Job</p>"+jobHeader.append(importContent.toString()).toString()
			+"</br><p style='color: Blue'>Import Job</p>"+jobHeader.append(otherContent.toString()).toString();		
			// Send the actual HTML message, as big as you like
			message.setContent(mailbody, "text/html");

			// Send message
			Transport.send(message);

			System.out.println("Email Sent successfully....");

		} catch (MessagingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

}
