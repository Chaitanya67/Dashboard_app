package com.infa.ms.dashboard.monitoring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerJobInformation;
import com.infa.ms.dashboard.monitoring.model.CustomerServiceStatus;

@Repository
public interface CustomerJobInformationRepository extends JpaRepository<CustomerJobInformation,Integer> { 

	public List<CustomerJobInformation> findByCustomer(Customer customer);
}
