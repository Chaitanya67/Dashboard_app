package com.infa.ms.dashboard.monitoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infa.ms.dashboard.monitoring.model.CustomerMSDetail;

@Repository
public interface CustomerMSDetailRepository extends JpaRepository<CustomerMSDetail,Integer> {

	
}
