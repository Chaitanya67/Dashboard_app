package com.infa.ms.dashboard.monitoring.controller;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;
import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;
import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.repository.CustomerRepository;
import com.infa.ms.dashboard.monitoring.repository.MasterDataRepository;

@Controller
public class IssueTrackerController {
	@Autowired
	CustomerRepository customerRepository;
	
	
	@Autowired
	MasterDataRepository masterDataRepository;


	@GetMapping("/issueTrackerSummary")
	public String issueTrackerSummary(@RequestParam(name = "id", required = true) Integer id, Model model) 
	{/*
		XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream("C:\\Users\\abalacha\\Documents\\Hackfest\\Weekly Issue vs Hours Tracker V 1.0_CIMB.xlsx"));
        XSSFSheet myExcelSheet = myExcelBook.getSheet("Issue Tracker - Internal");
        HashMap<Integer, ArrayList<String>> data = new HashMap<>();
        HashMap<String, Integer> Count = new HashMap<String, Integer>();
        String keyvalue = null;
        int flag = 0;
        int skip = 0;
        Iterator<Row> itr = myExcelSheet.iterator();//iterating over excel file  
        itr.next();
        itr.next();
        while (itr.hasNext())                 
        {  
	       	Row row = itr.next();
	       	if(row.getCell(0).getCellType() == CellType.BLANK) {
	       		break;
	       	}
	        String ticket_number = row.getCell(0).getStringCellValue();
	        String ticket_type = row.getCell(1).getStringCellValue();
	        Date Reported_on = row.getCell(3).getDateCellValue();
	        String Priority = row.getCell(5).getStringCellValue();
	        String Status = row.getCell(6).getStringCellValue();
	        String Component = row.getCell(7).getStringCellValue();
	        
	        if(Status.length()>0) {
	        	if(Count.containsKey(Status)) {
	        		Count.put(Status,Count.get(Status)+1);
	        	}
	        	else if(!Count.containsKey(Status)) {
	        		Count.put(Status,1);
	        	}
	        }
	        if(Priority.length()>0) {
	        	if(Count.containsKey(Priority)) {
	        		Count.put(Priority,Count.get(Priority)+1);
	        	}
	        	else if(!Count.containsKey(Priority)) {
	        		Count.put(Priority,1);
	        	}
	        }
	        if(Component.length()>0) {
	        	if(Count.containsKey(Component)) {
	        		Count.put(Component,Count.get(Component)+1);
	        	}
	        	else if(!Count.containsKey(Component)) {
	        		Count.put(Component,1);
	        	}
	        }
	    }
        Gson gsonObj = new Gson();
        Map<Object, Object> map = null;
    	List<Map<Object, Object>> list = new ArrayList<Map<Object, Object>>();
        for (Map.Entry<String,Integer> entry : Count.entrySet())   
        {
        	map = new HashMap<Object, Object>();
        	map.put("label", entry.getKey());
        	map.put("y", entry.getValue());
        	list.add(map);
        }
        String dataPoints = gsonObj.toJson(list);
        
        
        model.addAttribute("Row", dataPoints);
        Optional<Customer> customer=customerRepository.findById(1);
		Customer cust=customer.get();
		model.addAttribute("customerList",customerRepository.findAll()	);
		System.out.println("\n*****************************"+cust.getCustomerInfaDetail());
		model.addAttribute("customerDetail",cust.getCustomerInfaDetail());
		return "issueTrackerstatis";
*/	
		model.addAttribute("customerID", id);

		Optional<Customer> customer = customerRepository.findById(id);
		Customer cust = customer.get();
		model.addAttribute("customerName", cust.getName());
		model.addAttribute("customerList", customerRepository.findAll());
		model.addAttribute("customerProductDetail", cust.getCustInfaProductDetail());
		
		for ( CustInfaProductDetail dd:cust.getCustInfaProductDetail()){
			System.out.println( dd.getCustomerServiceStatus());
		}
		
		model.addAttribute("component",masterDataRepository.findByGroupID(3));

		return "issueTrackerSummary";	
	}
}
