package com.infa.ms.dashboard.monitoring.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.heiler.pim.webservice.client.RestClient;
import com.heiler.pim.webservice.client.list.EntityItemTable;
import com.heiler.pim.webservice.client.list.EntityItemTableRow;
import com.heiler.pim.webservice.client.list.ListReadRequest;
import com.heiler.pim.webservice.client.list.ReportQuery;
import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;
import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerJobInformation;
import com.infa.ms.dashboard.monitoring.model.CustomerServiceStatus;
import com.sun.jersey.api.client.filter.ClientFilter;

import java.net.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class MonitoringUtility {

	public List<CustomerServiceStatus> urlMonitoring(Integer CustId, List<CustInfaProductDetail> productList,
			String restUser, String passeword) {

		String[] URL_List = null;
		String[] Hostnames = null;
		String url = "";
		String Result = "";
		List<CustomerServiceStatus> statusList = new ArrayList<CustomerServiceStatus>();

		for (CustInfaProductDetail product : productList) {

			url = product.getURL();
			int code = 0;
			try {
				// URL siteURL = new URL(url);
				HttpURLConnection.setFollowRedirects(false);
				HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
				con.setConnectTimeout(1000);
				con.setReadTimeout(1000);
				con.setRequestMethod("HEAD");
				code = con.getResponseCode();

				if (code == 200) {
					Result = "Stable";
				} else {
					Result = "Unstable";
				}
			} catch (Exception e) {
				Result = "Unstable";

			}
			CustomerServiceStatus serviceStatus = new CustomerServiceStatus(Result, product,
					product.getCustomer().getId());
			statusList.add(serviceStatus);
		}

		return statusList;

	}

	public List<CustomerJobInformation> jobMonitoring(Customer customer, String restUser, String passeword) {
		RestClient restClient = new RestClient();
//		String basicUrl="https://cdw-dev.p360.informaticahostednp.com/rest";
		String basicUrl=customer.getRest_url();
		try {
			URI RestURI = new URI(basicUrl);
	  	restClient.loginWithBasicAuth(RestURI, restUser, passeword, Locale.ENGLISH);					}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		LocalDateTime tempendtime = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

		String endtime = format.format(tempendtime);
		// String endtime="2019-07-10T20:00:00";
		Integer interval = 24;
		String currentstate = "canceled.ok,canceled.info,canceled.warning,canceled.error,canceled.system,canceled.critical,canceled.shutdown,canceled.pending,queued.workload,finished.warning,running.warning,running.error,finished.error,finished.ok,finished.info";
		String starttime = "";
		starttime = tempendtime.minusHours(interval).format(format);

		// By search query to retrieve the details
		ReportQuery reportQuery = new ReportQuery("bySearch").addParameterValue("query",
				"JobHistory.ModificationTime > " + starttime + " AND JobHistory.ModificationTime < " + endtime
						+ " AND JobHistory.CurrentState in (" + currentstate
						+ ") &fields=JobHistory.Id,JobHistory.ModificationTime,JobHistory.ScheduledAt,JobHistory.CurrentState,JobHistory.Progress,JobHistory.GroupKey1,JobHistory.GroupKey2,%20JobHistory.JobType,JobHistory.JobGroup");

		// REST API request for the above query

		ListReadRequest listReadRequest = restClient.createListReadRequest();
		EntityItemTable resultTable = listReadRequest
				.setFields("JobHistory.Id", "JobHistory.ModificationTime", "JobHistory.ScheduledAt", //$NON-NLS-1$
						"JobHistory.CurrentState", "JobHistory.Progress", "JobHistory.GroupKey1",
						"JobHistory.GroupKey2", "JobHistory.JobType", "JobHistory.JobGroup",
						"JobHistory.ProblemLogIdentifier,")
				.setPageSize(-1).setStartIndex(0).getRootItems("JobHistory", reportQuery);

		List<CustomerJobInformation> statusList = new ArrayList<CustomerJobInformation>();
		for (EntityItemTableRow row : resultTable) {
			
			List<Object> values = row.getValues();
			String jobID = (String) values.get(0);
			String jobModTime = (String) values.get(1);
			
			String jobScheduledAt = (String) values.get(2);
			String jobStatus = (String) values.get(3);
			String jobProgress = (String) values.get(4);
			String jobGroupKey1 = (String) values.get(5);
			String jobGroupKey2 = (String) values.get(6);
			String jobType = (String) values.get(7);
			String jobGroup = (String) values.get(8);
			String problemLogIdentifier = (String) values.get(9);
			String jobName = "";
			String timestamp = "";
			System.out.println("jobGroupKey1"+jobGroupKey1+" jobGroupKey2 "+jobGroupKey2);
			// String jobmodtime = format.format_time(JobModTime.substring(0,
			// 23));
			// String jobscheduledat =
			// format.format_time(JobScheduledAt.substring(0, 23));
			CustomerJobInformation jobInfo=null;
			System.out.println("jobModTime"+jobModTime);
			if (jobType.contains("Inbox")) {
				 if(jobGroupKey2 == null || jobGroupKey1.isEmpty()){
					 jobGroupKey2="Hotfolder Processing"; 
				 }
				jobInfo=new CustomerJobInformation(jobID, jobGroupKey2, jobType, jobStatus, jobModTime,jobGroup);
			} else if (jobType.contains("Export")) {
				
				 jobInfo=new CustomerJobInformation(jobID, jobGroupKey1, jobType, jobStatus, jobModTime,jobGroup);
			} else {
				if(jobGroupKey1 == null || jobGroupKey1.isEmpty()){
					 jobGroupKey1="SystemJob"; 
				 }
				jobInfo=new CustomerJobInformation(jobID, jobGroupKey1, jobType, jobStatus, jobModTime,jobGroup );
			}
			statusList.add(jobInfo);
		}
		return statusList;
	}
}
