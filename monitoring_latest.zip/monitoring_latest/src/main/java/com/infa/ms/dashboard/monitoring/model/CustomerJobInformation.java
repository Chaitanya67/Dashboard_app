package com.infa.ms.dashboard.monitoring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CustomerJobInformation")
public class CustomerJobInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "jobID")
	private String jobID;
	
	@Column(name = "jobname")
	private String jobName;

	@Column(name = "jobType")
	private String jobType;
	
	@Column(name = "jobStatus")
	private String jobStatus;
	
	@Column(name = "executionDate")
	private String executionDate;
	
	@Column(name = "jobGroup")
	private String jobGroup;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY )  
    @JoinColumn(name="customerID")  
    private Customer customer;
	
	
	public CustomerJobInformation(String jobID, String jobName, String jobType, String jobStatus, String executionDate,
			String jobGroup) {
		super();
		this.jobID = jobID;
		this.jobName = jobName;
		this.jobType = jobType;
		this.jobStatus = jobStatus;
		this.executionDate = executionDate;
		this.jobGroup=jobGroup;
	//	this.customer = customer;
	}

	
	public CustomerJobInformation() {
		super();
	}


	public String getJobID() {
		return jobID;
	}

	public void setJobID(String jobID) {
		this.jobID = jobID;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(String executionDate) {
		this.executionDate = executionDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Integer getId() {
		return id;
	}


	public String getJobGroup() {
		return jobGroup;
	}


	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}


}
