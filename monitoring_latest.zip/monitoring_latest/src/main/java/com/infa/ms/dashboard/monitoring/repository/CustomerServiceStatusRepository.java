package com.infa.ms.dashboard.monitoring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;
import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerServiceStatus;


@Repository
public interface CustomerServiceStatusRepository extends JpaRepository<CustomerServiceStatus,Integer> {
	
	public List<CustomerServiceStatus> findByCustomerID(Integer customerID);

}

