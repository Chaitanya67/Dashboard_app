package com.infa.ms.dashboard.monitoring.model;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "customer")
public class Customer {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    
	private String name;
    
    private String customerFullName;
    
    @Temporal(TemporalType.DATE)
	private Date ms_endDate;
    

	private String rest_UserName;
	private String rest_password;
	private String rest_url;

	public String getRest_url() {
		return rest_url;
	}

	public void setRest_url(String rest_url) {
		this.rest_url = rest_url;
	}
	
    public Date getMs_endDate() {
		return ms_endDate;
	}

	public void setMs_endDate(Date ms_endDate) {
		this.ms_endDate = ms_endDate;
	}

	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY )
    private MasterData infaProduct;
    
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY )
    private MasterData customerType;
    
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY )  
    @JoinColumn(name="customerID")  
    private List<CustomerMSDetail> customerMSDetail;  
    
    @OneToMany(cascade = CascadeType.ALL,  fetch = FetchType.LAZY  )  
    @JoinColumn(name="customerID")  
    private List<CustInfaProductDetail> custInfaProductDetail;
    
    @OneToMany(cascade = CascadeType.ALL,  fetch = FetchType.LAZY  )  
    @JoinColumn(name="customerID")  
    private List<CustomerJobInformation> customerJobInformation;
    
    @OneToOne(mappedBy="customer")
	private CustomerStatus customerStatus;
    
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCustomerFullName() {
		return customerFullName;
	}

	public void setCustomerFullName(String customerFullName) {
		this.customerFullName = customerFullName;
	}

	public MasterData getInfaProduct() {
		return infaProduct;
	}

	public void setInfaProduct(MasterData infaProduct) {
		this.infaProduct = infaProduct;
	}

	public MasterData getCustomerType() {
		return customerType;
	}

	public void setCustomerType(MasterData customerType) {
		this.customerType = customerType;
	}

	public List<CustomerMSDetail> getCustomerMSDetail() {
		return customerMSDetail;
	}

	public void setCustomerMSDetail(List<CustomerMSDetail> customerMSDetail) {
		this.customerMSDetail = customerMSDetail;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRest_UserName() {
		return rest_UserName;
	}

	public void setRest_UserName(String rest_UserName) {
		this.rest_UserName = rest_UserName;
	}

	public String getRest_password() {
		return rest_password;
	}

	public void setRest_password(String rest_password) {
		this.rest_password = rest_password;
	}

	public List<CustInfaProductDetail> getCustInfaProductDetail() {
		return custInfaProductDetail;
	}

	public void setCustInfaProductDetail(List<CustInfaProductDetail> custInfaProductDetail) {
		this.custInfaProductDetail = custInfaProductDetail;
	}

	public List<CustomerJobInformation> getCustomerJobInformation() {
		return customerJobInformation;
	}

	public void setCustomerJobInformation(List<CustomerJobInformation> customerJobInformation) {
		this.customerJobInformation = customerJobInformation;
	}

	public CustomerStatus getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(CustomerStatus customerStatus) {
		this.customerStatus = customerStatus;
	}

	
    
}
