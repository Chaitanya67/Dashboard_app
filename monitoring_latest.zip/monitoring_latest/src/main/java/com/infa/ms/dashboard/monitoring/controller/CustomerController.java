package com.infa.ms.dashboard.monitoring.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties.View;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;
import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustomerJobInformation;
import com.infa.ms.dashboard.monitoring.model.CustomerServiceStatus;
import com.infa.ms.dashboard.monitoring.model.CustomerStatus;

import com.infa.ms.dashboard.monitoring.repository.CustomerJobInformationRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerProductDetailRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerServiceStatusRepository;
import com.infa.ms.dashboard.monitoring.repository.CustomerStatusRepository;
import com.infa.ms.dashboard.monitoring.repository.MasterDataRepository;
import com.infa.ms.dashboard.monitoring.utility.MailUtility;
import com.infa.ms.dashboard.monitoring.utility.MonitoringUtility;
import com.sun.jersey.api.view.Viewable;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class CustomerController {
	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	MonitoringUtility monitoringUtility;
	
	@Autowired
	CustomerProductDetailRepository customerProductDetailRepository;
	
	@Autowired
	CustomerServiceStatusRepository customerServiceStatusRepository;

	@Autowired
	CustomerStatusRepository customerStatusRepository;

	@Autowired
	CustomerJobInformationRepository customerJobInformationRepository;
	
	@Autowired
	MailUtility mailUtility;
	
	@Autowired
	MasterDataRepository masterDataRepository;

	
	@GetMapping("/customerDetail")
	public String greeting(@RequestParam(name = "id", required = true) Integer id, Model model) {
		model.addAttribute("customerID", id);
		model.addAttribute("component",masterDataRepository.findByGroupID(3));

		Optional<Customer> customer = customerRepository.findById(id);
		Customer cust = customer.get();
		model.addAttribute("customerName", cust.getName());
		model.addAttribute("customerList", customerRepository.findAll());
		model.addAttribute("customerProductDetail", cust.getCustInfaProductDetail());
		
		for ( CustInfaProductDetail dd:cust.getCustInfaProductDetail()){
			System.out.println( dd.getCustomerServiceStatus());
		}
		return "customerDetail";
	}

	/*@GetMapping("/jobInformation")
	public String jobInformation(@RequestParam(name = "name", required = false, defaultValue = "World") String name,
			Model model) {
		model.addAttribute("customerName", name);
		Optional<Customer> customer = customerRepository.findById(1);
		Customer cust = customer.get();
		model.addAttribute("customerList", customerRepository.findAll());
		System.out.println("\n*****************************" + cust.getCustInfaProductDetail());
		model.addAttribute("customerDetail", cust.getCustInfaProductDetail());
		return "jobInformation";
	}*/

	@GetMapping("/sendMail")
	public String sendMail(@RequestParam(name = "id", required = true) Integer id, Model model) {
		
		try {
			mailUtility.sendCusotmerStatus(customerRepository.findById(id).get());
		} catch (Exception e) {
			System.out.println("Exception on mail trigger");
		}
		return "redirect:customerDetail?id="+id;
	}
	
	@GetMapping("/statusRefresh")
	public String statusRefresh(@RequestParam(name = "id", required = true) Integer id, Model model) {
		Optional<Customer> custOpt=customerRepository.findById(id);
		Customer cust=custOpt.get();
		
		List<CustInfaProductDetail> productList=customerProductDetailRepository.findByCustomer(cust);
		System.out.println("****productList*****"+productList);
		List<CustomerServiceStatus> statuslist=monitoringUtility.urlMonitoring(id, productList, cust.getRest_UserName(), cust.getRest_password());
		
		customerServiceStatusRepository.deleteInBatch(customerServiceStatusRepository.findByCustomerID(id));
		customerServiceStatusRepository.saveAll(statuslist);
		CustomerStatus custStatus=new CustomerStatus("Stable",cust);
		for (CustomerServiceStatus status:statuslist){
			if(status.getStatus().equals("Unstable")){
				custStatus.setStatus(status.getStatus());
				break;
			}
		}
		customerStatusRepository.delete(cust.getCustomerStatus());
		customerStatusRepository.save(custStatus);
		return "redirect:customerDetail?id="+id;
	}
	
	//edit customer
	@GetMapping("/updateCus")
	public String updatebyid(@RequestParam Integer id,Model model) {
	Optional<Customer> cusopt = customerRepository.findById(id);

	model.addAttribute("customer", cusopt);
	return "Update";

	}
	
	//save customer(old)
//	@PostMapping("/createCus")
//	public String createCus(@ModelAttribute("customer") Customer customer) {
//	customerRepository.save(customer);
//	String status="Unknown";
//	customerRepository.save(customer);
//	CustomerStatus new1=new CustomerStatus(status,customer);
//	customerStatusRepository.save(new1);
//	return "redirect:/home";
//	}
	
//	@PostMapping("/createCus")
//	public String createCus(String name,String fullName,String endDate,String restName,String restPassword,ArrayList<List<String>> infaProducts ) {
//	System.out.println(name+"test");
//	System.out.println(fullName);
//	System.out.println(endDate);
//	System.out.println(restName);
//	System.out.println(restPassword);
//	System.out.println(infaProducts);
//	return "redirect:/home";
//	}
	
//	@PostMapping("/createCus")
//	public String createCus( @RequestBody String fu ) {
//		HashMap<String , String> values = new HashMap<String,String>();
//		String[] vals = fu.split("&");
//		System.out.println(vals.toString());
//		for(int i=0;i<vals.length;i++) {
//			String[] map = vals[i].split("=");
//			values.put(map[0], map[1]);
//			map = new String[0];
//		}
//		System.out.println(values);
//		System.out.println("##################################################");
//		System.out.println("InfaProducts : ");
//		System.out.println("Prod 1 - Record : " + values.get("record") + " " + "Component : " + values.get("component") + " URL : " + values.get("url") + " License : " + values.get("license"));
//		for(int i=2;i<=Integer.parseInt(values.get("numberofprods"));i++) {
//		System.out.println("Prod " + (i) +" - Record : " + values.get("record" + i) + " " + "Component : " + values.get("component" + i) + " URL : " + values.get("url" + i) + " License : " + values.get("license" + i));
//		}
//		return "redirect:home";
//	}
	
	@PostMapping("/createCus")
	public String createCus( @RequestBody String fu ) {
		HashMap<String , String> values = new HashMap<String,String>();
		String[] vals = fu.split("&");
		for(int i=0;i<vals.length;i++) {
		String[] map = vals[i].split("=");
		values.put(map[0], map[1]);
		map = new String[0];
		}
	
		System.out.println(fu);
		ArrayList<String> keys = new ArrayList<String>(values.keySet());
		System.out.println(keys);
		System.out.println("##################################################");
		System.out.println("InfaProducts");
		System.out.println("Component | Url | License Date");
	
		char index='0';
		for(int i=0;i<keys.size();i++) {
	
		if(keys.get(i).contains("component")) {
		index = keys.get(i).charAt(keys.get(i).length()-1);
		System.out.println(values.get("component" + index) + " | " + values.get("url" + index) + " | " + values.get("license" + index));
	
	
		}
		}
	
		// ***** Other variables can be fetched by :
		//		values.get("name");
		//		values.get("primary");
	
		return "redirect:home";


	}
	
	//add new customer v1
//	@GetMapping("/addCus") /*this thing should be unique, model class is used if you want to pass something to your jsp page*/
//	public String addCus(@ModelAttribute("customer") Customer customer) {
//	//model.addAttribute("customerID", id);
//	return "Update";
//	}
	
//	//save customer
//	@RequestMapping(value = "/createCus", method = RequestMethod.POST)
//	public String createCus(@ModelAttribute("customer") Customer customer) {
//	customerRepository.save(customer);
//	return "redirect:/home";
//	}
	
//	@RequestMapping(value = "/updateCus", method = RequestMethod.GET)
//    public String showUpdateEmployeePage(@RequestParam Integer id, ModelMap model) {
//        Optional<Customer> cusopt = customerRepository.findById(id);
//        Customer cus=cusopt.get();
//        System.out.println(cus+"qwerty");
////        System.out.println(cus.getName());
//        //model.put("empval",emp);
//        model.addAttribute("cusval",customerRepository.findById(id));
//        System.out.println("*******wwww*******");
//        return "Update";   
//    }
	
	 @RequestMapping(value = "/deleteCus")
	    public String deleteCus(@RequestParam Integer id,Model model) {
		 Optional < Customer > cus = customerRepository.findById(id);
		System.out.println(cus.get()+"qwerty");
		System.out.println(cus.get().getId());
	        if (cus.isPresent()) {
	        	System.out.println("Test");
	        	customerRepository.delete(cus.get());
	        }
//		 	customerRepository.deleteById(id);
	        return "redirect:/home";
	    } 
	
	@GetMapping("/jobInformation")
	public String jobInformation(@RequestParam(name = "id", required = true) Integer id, Model model) {
		model.addAttribute("customerList", customerRepository.findAll());
		
		Optional<Customer> custOpt=customerRepository.findById(id);
		Customer cust=custOpt.get();
		model.addAttribute("customerName", cust.getName());
		model.addAttribute("customerID", id);
		model.addAttribute("component", masterDataRepository.findByGroupID(3));

		List<CustomerJobInformation> statuslist=cust.getCustomerJobInformation();
	//	List<CustomerJobInformation> statuslist=monitoringUtility.jobMonitoring(cust, cust.getRest_UserName(), cust.getRest_password());
		//customerJobInformationRepository.deleteInBatch(customerJobInformationRepository.findByCustomer(cust));
		//cust.setCustomerJobInformation(statuslist);
	//	customerRepository.save(cust);
		
		
		//customerJobInformationRepository.saveAll(statuslist);
		List<CustomerJobInformation> exportStatuslist=new ArrayList<CustomerJobInformation>();
		List<CustomerJobInformation> importStatuslist=new ArrayList<CustomerJobInformation>();
		List<CustomerJobInformation> otherStatuslist=new ArrayList<CustomerJobInformation>();
		for(CustomerJobInformation status: statuslist){
			if (status.getJobGroup().equals("Export")){
				exportStatuslist.add(status);
			}else if (status.getJobGroup().equals("ImportGroup")){
				importStatuslist.add(status);
			}else{
				otherStatuslist.add(status);
			}
		}
		
		model.addAttribute("exportStatuslist", exportStatuslist);
		model.addAttribute("importStatuslist", importStatuslist);
		model.addAttribute("otherStatuslist", otherStatuslist);
		return "jobInformation";
	}
	
	@GetMapping("/jobStatusRefresh")
	public String jobStatusRefresh(@RequestParam(name = "id", required = true) Integer id, Model model) {
		model.addAttribute("customerList", customerRepository.findAll());
		
		Optional<Customer> custOpt=customerRepository.findById(id);
		Customer cust=custOpt.get();
		model.addAttribute("customerName", cust.getName());
		model.addAttribute("customerID", id);
		List<CustomerJobInformation> statuslist=monitoringUtility.jobMonitoring(cust, cust.getRest_UserName(), cust.getRest_password());
		//customerJobInformationRepository.deleteInBatch(customerJobInformationRepository.findByCustomer(cust));
		cust.setCustomerJobInformation(statuslist);
		customerRepository.save(cust);
		//customerJobInformationRepository.saveAll(statuslist);
		List<CustomerJobInformation> exportStatuslist=new ArrayList<CustomerJobInformation>();
		List<CustomerJobInformation> importStatuslist=new ArrayList<CustomerJobInformation>();
		List<CustomerJobInformation> otherStatuslist=new ArrayList<CustomerJobInformation>();
		for(CustomerJobInformation status: statuslist){
			if (status.getJobGroup().equals("Export")){
				exportStatuslist.add(status);
			}else if (status.getJobGroup().equals("ImportGroup")){
				importStatuslist.add(status);
			}else{
				otherStatuslist.add(status);
			}
		}
		
		model.addAttribute("exportStatuslist", exportStatuslist);
		model.addAttribute("importStatuslist", importStatuslist);
		model.addAttribute("otherStatuslist", otherStatuslist);
		return "jobInformation";
	}
	
}
