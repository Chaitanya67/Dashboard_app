package com.infa.ms.dashboard.monitoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infa.ms.dashboard.monitoring.model.Customer;
import com.infa.ms.dashboard.monitoring.model.CustInfaProductDetail;

@Repository
public interface CustomerInfaDetailRepository extends JpaRepository<CustInfaProductDetail,Integer> {

	
}