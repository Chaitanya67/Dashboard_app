package com.infa.ms.dashboard.monitoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infa.ms.dashboard.monitoring.model.CustomerStatus;

@Repository
public interface CustomerStatusRepository extends JpaRepository<CustomerStatus,Integer> {

}
