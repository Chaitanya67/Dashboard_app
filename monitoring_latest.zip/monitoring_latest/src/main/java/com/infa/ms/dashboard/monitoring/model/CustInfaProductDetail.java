package com.infa.ms.dashboard.monitoring.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "Customer_Infa_Detail")
public class CustInfaProductDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "component", length = 100)
	private String component;

	@Column(name = "URL", length = 200)
	private String URL;

	@Temporal(TemporalType.DATE)
	private Date licenseDate;

	@OneToOne(mappedBy="custInfaProductDetail")
	private CustomerServiceStatus customerServiceStatus;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY )  
    @JoinColumn(name="customerID")  
    private Customer customer;

	public CustInfaProductDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustInfaProductDetail(String component, Date licenseDate) {
		super();
		this.component = component;
		this.licenseDate = licenseDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public Date getLicenseDate() {
		return licenseDate;
	}

	public void setLicenseDate(Date licenseDate) {
		this.licenseDate = licenseDate;
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String uRL) {
		URL = uRL;
	}

	public CustomerServiceStatus getCustomerServiceStatus() {
		return customerServiceStatus;
	}

	public void setCustomerServiceStatus(CustomerServiceStatus customerServiceStatus) {
		this.customerServiceStatus = customerServiceStatus;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	
}
