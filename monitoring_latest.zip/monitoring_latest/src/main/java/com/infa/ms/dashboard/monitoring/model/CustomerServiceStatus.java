package com.infa.ms.dashboard.monitoring.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CustomerServiceStatus")
public class CustomerServiceStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "status")
	private String status;

	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "monitoringDate")
	private String monitoringDate;

	@Column(name = "customerID")
	private Integer customerID;



	@OneToOne(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumn(name = "InfaProductID")
	private CustInfaProductDetail custInfaProductDetail;

	public CustomerServiceStatus() {
		super();
	}

	public CustomerServiceStatus(String status, CustInfaProductDetail custInfaProductDetail, Integer customerID) {
		super();
		this.status = status;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		
		this.monitoringDate = formatter.format(date);
		this.custInfaProductDetail = custInfaProductDetail;
		this.customerID = customerID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CustInfaProductDetail getCustInfaProductDetail() {
		return custInfaProductDetail;
	}

	public void setCustInfaProductDetail(CustInfaProductDetail custInfaProductDetail) {
		this.custInfaProductDetail = custInfaProductDetail;
	}

	public Integer getId() {
		return id;
	}

	public Integer getCustomerID() {
		return customerID;
	}

	public void setCustomerID(Integer customerID) {
		this.customerID = customerID;
	}

	public String getMonitoringDate() {
		return monitoringDate;
	}

	public void setMonitoringDate(String monitoringDate) {
		this.monitoringDate = monitoringDate;
	}
	
}
